package myLibraries.io;

/*
 * ZipFile.java
 *
 * Version:
 *     $1.0$
 *
 * Revisions:
 *     $0.0$
 */

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Do self-designing zipping procedure with multi-threading functionality
 *
 * @author       Xiaoyu Tongyang or call me sora for short
 */

public final class ZipFile implements Runnable {
    /** buffer size */
    private static final int BUFFER = 1024;
    private final List<File> folderPaths = new ArrayList<>();
    private final List<File> filePaths = new ArrayList<>();
    private final List<File> fileList = new ArrayList<>();
    private String inputFileName;
    private String zipFileName; // file name after zipping
    private String srcPath;  // path in which a zip is
    private String removedPath; // path needed to remove
    private boolean ifRemovedPrefixPath; // true, do removal; false, not do

    public ZipFile( String inputFileName, String zipFileName, String srcPath, String removedPath, boolean ifRemovedPrefixPath ) {
        this.inputFileName = inputFileName;
        this.srcPath = srcPath;
        this.zipFileName = zipFileName;
        this.removedPath = removedPath;
        this.ifRemovedPrefixPath = ifRemovedPrefixPath;
    }

    public ZipFile( String[] args ) {
        paraphraseArgs( args );
    }

    /**
     * compression
     * @return            how many files will have been zipped in the end
     */

    private int doZip() {
        // buffer
        byte[] buffer = new byte[BUFFER];
        // entry of a zip file
        ZipEntry zipEntry = null;
        // length to read
        int readLength = 0;
        // file name after zipping
        String newZipFileName;
        // how many files will have been zipped in the end
        int count = 0;

        if( zipFileName == null || zipFileName.length() == 0 ) {
            newZipFileName= srcPath + "newZip.zip";
        }else {
            newZipFileName = srcPath + "\\" + zipFileName;
        }

        try ( ZipOutputStream zipOutputStream = new ZipOutputStream( new FileOutputStream( newZipFileName ) ) ) {

            for (File file : fileList) {
                // if a file, zip it
                if ( file.isFile() ) {
                    count++;
                    zipEntry = new ZipEntry( getRelativePath( srcPath, file ) );
                    zipEntry.setSize( file.length() );
                    zipEntry.setTime( file.lastModified() );
                    zipOutputStream.putNextEntry( zipEntry );
                    InputStream inputStream = new BufferedInputStream( new FileInputStream(file) );
                    while ( ( readLength = inputStream.read( buffer, 0, BUFFER ) ) != -1 ) {
                        zipOutputStream.write( buffer, 0, readLength );
                    }
                    inputStream.close();
                } else {
                    zipEntry = new ZipEntry(getRelativePath( srcPath, file ) + "/");
                    zipOutputStream.putNextEntry(zipEntry);
                }
            }
        } catch ( FileNotFoundException e ) {
            e.printStackTrace();
            return -1;
        } catch ( IOException e ) {
            e.printStackTrace();
            return -2;
        }

        return count;
    }

    /**
     * get file list from srcFile
     * @param srcFile  file path
     */

    private void getAllFiles( File srcFile ) {
        File[] tmp = srcFile.listFiles();
        assert tmp != null;
        for ( File file : tmp ) {
            if ( file.isFile() ) {
                fileList.add(file);
            } else if ( file.isDirectory() ) {
                // if the directory is no empty, and recursively find its child files and directories in it
                if ( Objects.requireNonNull( file.listFiles() ) .length != 0 ) {
                    getAllFiles(file);
                }
                // if the directory is empty, then add is into fileList
                else {
                    fileList.add(file);
                }
            }
        }
    }

    private  String getRelativePath( String dirPath, File file ) {
        File dir = new File( dirPath );
        String relativePath = file.getName();

        while ( true ) {
            file = file.getParentFile();
            if (file == null) {
                break;
            }

            if ( file.equals(dir) ) {
                break;
            } else {
                if ( file.getName().equals( removedPath ) ) break;
                relativePath = file.getName() + "\\" + relativePath;
            }
        }

        // do the removal procedure
/*        int index = removedPath == null ? -1 : relativePath.indexOf( removedPath );
        relativePath = ifRemovedPrefixPath ?
                ( index > -1 ? relativePath.substring( index + removedPath.length() ) : relativePath )
                : relativePath;*/
        return  relativePath;
    }

    /**
     * read an input path from a file
     * */

    private void readFromFile() {
        try ( Scanner myScanner = new Scanner( new File( inputFileName ) ) ) {
            while ( myScanner.hasNext() ) {
                String path = myScanner.nextLine();
                if ( path.isEmpty() ) continue; // skip only a new line

                preprocessInputPaths( path );
            }

        } catch ( FileNotFoundException e ) {
            e.printStackTrace();
        }
    }

    /**
     * add all paths of files or folders together to be zipped
     * */

    private void obtainZippedAllPaths() {
        for ( File file : folderPaths )
            getAllFiles( file );

        fileList.addAll( filePaths );
    }

    /**
     * separate files or folders
     * */

    private void preprocessInputPaths( String path ) {
        File aFile = new File( path );
        if ( aFile.isFile() )
            filePaths.add( aFile );
        else if ( aFile.isDirectory() )
            folderPaths.add( aFile );
        else {
            System.err.println( "\"" + path + "\" is invalid! Please check it out" );
        }
    }

    /**
     * do the zipping procedure
     * */

    public void doTheJob() {
        readFromFile();
        System.out.println("Starting zipping input file: "+ inputFileName + "------------->");
        obtainZippedAllPaths();
        System.out.printf("Done zipping %s -> (%d) files or folders have been zipped\n", inputFileName, doZip() );
    }

    /**
     * command line formats:
     * java ZipFile -inputFileName inputFileName -zipFileName zipFileName -srcPath srcPath -removedPath removedPath -ifRemovedPrefixPath ifRemovedPrefixPath
     * For example:
     * java ZipFile -inputFileName input_file_1.txt -zipFileName himea_2.zip -srcPath D:\ZipFile\src -removedPath test_folder_3\ -ifRemovedPrefixPath true
     * java ZipFile -inputFileName input_file_1.txt -zipFileName himea_2.zip -srcPath D:\ZipFile\src -removedPath sources\ -ifRemovedPrefixPath true
     * Jump to designated path:
     * cd /d D:\ZipFile\src
     * */

    private void paraphraseArgs( String[] args ) {
        for ( int i = 0; i < args.length; i++ ) {
            switch ( args[i] ) {
                case "-inputFileName":
                    inputFileName = args[++i];
                    break;
                case "-zipFileName":
                    zipFileName = args[++i];
                    break;
                case "-srcPath":
                    srcPath = args[++i];
                    break;
                case "-removedPath":
                    removedPath = args[++i];
                    ifRemovedPrefixPath = true;
                    break;
                default:
                    System.err.println("Cannot reach here in paraphraseArgs()");
                    System.exit(1);
            }
        }
    }

    /**
     * support multi-threads
     * */

    @Override
    public void run() {
        doTheJob();
    }

    public static void main( String[] args ) {
        if ( args.length < 6 || args.length > 10 ) {
            System.err.printf("%s:\n%s", "Command line args are invalid. Please use the following formats",
                    "java ZipFile -inputFileName inputFileName -zipFileName zipFileName -srcPath srcPath " +
                            "-removedPath removedPath -ifRemovedPrefixPath ifRemovedPrefixPath");
            return;
        }

        // zip multiple folders and files into one zip file
        // -inputFileName input_file_1.txt -zipFileName himea_2.zip -srcPath src -removedPath ZipFile\
        // -inputFileName input_file_1.txt -zipFileName himea_2.zip -srcPath src -removedPath ZipFile
        // -inputFileName input_file_1.txt -zipFileName himea_2.zip -srcPath src
        new Thread( new ZipFile( args ) ).start();

//        doTheJob("input_file.txt", "himea.zip", "src");
//        new Thread( new ZipFile("input_file_1.txt", "himea_2.zip", "src", "test_folder_3/", true ) ).start();
//        new Thread( new ZipFile("input_file_1.txt", "himea_1.zip", "src") ).start();
    }
}