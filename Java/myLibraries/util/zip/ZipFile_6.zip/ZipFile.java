package myLibraries.io;

/*
 * ZipFile.java
 *
 * Version:
 *     $1.0$
 *
 * Revisions:
 *     $0.0$
 */

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Do self-designing zipping procedure with multi-threading functionality
 *
 * @author       Xiaoyu Tongyang or call me sora for short
 */

public final class ZipFile implements Runnable {
    /** buffer size */
    private static final int BUFFER = 1024;
    private String inputFileName;
    private String zipFileName;
    private String srcPath;
    private String removedPath;
    private boolean ifRemovedPrefixPath;

    public ZipFile( String inputFileName, String zipFileName, String srcPath, String removedPath, boolean ifRemovedPrefixPath ) {
        this.inputFileName = inputFileName;
        this.srcPath = srcPath;
        this.zipFileName = zipFileName;
        this.removedPath = removedPath;
        this.ifRemovedPrefixPath = ifRemovedPrefixPath;
    }

    public ZipFile( String[] args ) {
        paraphraseArgs( args );
    }

    /**
     * compression
     * @param srcPath                   path in which a zip is
     * @param zipFileName               file name after zipping
     * @param removedPath               path needed to remove
     * @param ifRemovedPrefixPath       true, do removal; false, not do
     * @return                          how many files will have been zipped in the end
     */

    private int doZip(String zipFileName, String srcPath, List<File> fileList, String removedPath, boolean ifRemovedPrefixPath) {
        // buffer
        byte[] buffer = new byte[BUFFER];
        // entry of a zip file
        ZipEntry zipEntry = null;
        // length to read
        int readLength = 0;
        // file name after zipping
        String newZipFileName;
        // how many files will have been zipped in the end
        int count = 0;

        if( zipFileName == null || zipFileName.length() == 0 ) {
            newZipFileName= srcPath + "newZip.zip";
        }else {
            newZipFileName = srcPath + "\\" + zipFileName;
        }

        try ( ZipOutputStream zipOutputStream = new ZipOutputStream( new FileOutputStream( newZipFileName ) ) ) {

            for (File file : fileList) {
                // if a file, zip it
                if ( file.isFile() ) {
                    count++;
                    zipEntry = new ZipEntry( getRelativePath( srcPath, file, removedPath, ifRemovedPrefixPath ) );
                    zipEntry.setSize( file.length() );
                    zipEntry.setTime( file.lastModified() );
                    zipOutputStream.putNextEntry( zipEntry );
                    InputStream inputStream = new BufferedInputStream( new FileInputStream(file) );
                    while ( ( readLength = inputStream.read( buffer, 0, BUFFER ) ) != -1 ) {
                        zipOutputStream.write( buffer, 0, readLength );
                    }
                    inputStream.close();
                } else {
                    zipEntry = new ZipEntry(getRelativePath( srcPath, file, removedPath, ifRemovedPrefixPath ) + "/");
                    zipOutputStream.putNextEntry(zipEntry);
                }
            }
        } catch ( FileNotFoundException e ) {
            e.printStackTrace();
            return -1;
        } catch ( IOException e ) {
            e.printStackTrace();
            return -2;
        }

        return count;
    }

    /**
     * get file list from srcFile
     * @param srcFile  file path
     */

    private void getAllFiles( File srcFile, List<File> fileList ) {
        File[] tmp = srcFile.listFiles();
        assert tmp != null;
        for ( File file : tmp ) {
            if ( file.isFile() ) {
                fileList.add(file);
            } else if (file.isDirectory()) {
                // if the directory is no empty, and recursively find its child files and directories in it
                if ( Objects.requireNonNull( file.listFiles() ) .length != 0) {
                    getAllFiles(file, fileList);
                }
                // if the directory is empty, then add is into fileList
                else {
                    fileList.add(file);
                }
            }
        }
    }

    private  String getRelativePath( String dirPath, File file, String removedPath, boolean ifRemovedPrefixPath ) {
        File dir = new File( dirPath );
        String relativePath = file.getName();

        while ( true ) {
            file = file.getParentFile();
            if (file == null) {
                break;
            }

            if ( file.equals(dir) ) {
                break;
            } else {
                relativePath = file.getName() + "\\" + relativePath;
            }
        }

        // do the removal procedure
        int index = relativePath.indexOf( removedPath );
        relativePath = ifRemovedPrefixPath ?
                ( index > -1 ? relativePath.substring( index + removedPath.length() ) : relativePath )
                : relativePath;
        return  relativePath;
    }

    /**
     * read an input path from a file
     * */

    private void readFromFile(String inputFileName, ZipData aZipData) {
        try ( Scanner myScanner = new Scanner( new File( inputFileName ) ) ) {
            while ( myScanner.hasNext() ) {
                String path = myScanner.nextLine();
                if ( path.isEmpty() ) continue; // skip only a new line

                preprocessInputPaths( path, aZipData.filePaths, aZipData.folderPaths );
            }

        } catch ( FileNotFoundException e ) {
            e.printStackTrace();
        }
    }

    /**
     * add all paths of files or folders together to be zipped
     * */

    private void obtainZippedAllPaths( ZipData aZipData ) {
        for ( File file : aZipData.folderPaths )
            getAllFiles( file, aZipData.fileList );

        aZipData.fileList.addAll( aZipData.filePaths );
    }

    /**
     * separate files or folders
     * */

    private void preprocessInputPaths(String path, List<File> filePaths, List<File> folderPaths) {
        File aFile = new File( path );
        if ( aFile.isFile() )
            filePaths.add( aFile );
        else if ( aFile.isDirectory() )
            folderPaths.add( aFile );
        else {
            System.err.println( "\"" + path + "\" is invalid! Please check it out" );
        }
    }

    /**
     * do the zipping procedure
     * */

    public void doTheJob( String inputFileName, String zipFileName, String srcPath, String removedPath, boolean ifRemovedPrefixPath) {
        ZipData aZipData = new ZipData();
        readFromFile( inputFileName, aZipData );
        System.out.println("Starting zipping input file: "+ inputFileName + "------------->");
        obtainZippedAllPaths( aZipData );
        System.out.printf("Done zipping %s -> (%d) files or folders have been zipped\n",
                inputFileName, doZip( zipFileName, srcPath, aZipData.fileList, removedPath, ifRemovedPrefixPath ) );
    }

    /**
     * command line formats:
     * java ZipFile -inputFileName inputFileName -zipFileName zipFileName -srcPath srcPath -removedPath removedPath -ifRemovedPrefixPath ifRemovedPrefixPath
     * For example:
     * java ZipFile -inputFileName input_file_1.txt -zipFileName himea_2.zip -srcPath D:\ZipFile\src -removedPath test_folder_3\ -ifRemovedPrefixPath true
     * java ZipFile -inputFileName input_file_1.txt -zipFileName himea_2.zip -srcPath D:\ZipFile\src -removedPath sources\ -ifRemovedPrefixPath true
     * Jump to designated path:
     * cd /d D:\ZipFile\src
     * */

    private void paraphraseArgs( String[] args ) {
        for ( int i = 0; i < args.length; i++ ) {
            switch ( args[i] ) {
                case "-inputFileName":
                    inputFileName = args[++i];
                    break;
                case "-zipFileName":
                    zipFileName = args[++i];
                    break;
                case "-srcPath":
                    srcPath = args[++i];
                    break;
                case "-removedPath":
                    removedPath = args[++i];
                    break;
                case "-ifRemovedPrefixPath":
                    ifRemovedPrefixPath = Boolean.parseBoolean( args[++i] );
                    break;
                default:
                    System.err.println("Cannot reach here in paraphraseArgs()");
                    System.exit(1);
            }
        }
    }

    /**
     * inner class to store data to be ready for zipping,
     * but this class is not necessary and could be merged in the Class ZipFile
     * */

    private static final class ZipData {
        private final List<File> folderPaths = new ArrayList<>();
        private final List<File> filePaths = new ArrayList<>();
        private final List<File> fileList = new ArrayList<>();
    }

    /**
     * support multi-threads
     * */

    @Override
    public void run() {
        doTheJob( inputFileName, zipFileName, srcPath, removedPath, ifRemovedPrefixPath );
    }

    public static void main( String[] args ) {
        if ( args.length != 10 ) {
            System.err.printf("%s:\n%s", "Command line args are invalid. Please use the following formats",
                    "java ZipFile -inputFileName inputFileName -zipFileName zipFileName -srcPath srcPath " +
                            "-removedPath removedPath -ifRemovedPrefixPath ifRemovedPrefixPath");
            return;
        }

        // zip multiple folders and files into one zip file
        new Thread( new ZipFile( args ) ).start();

//        doTheJob("input_file.txt", "himea.zip", "src");
//        new Thread( new ZipFile("input_file_1.txt", "himea_2.zip", "src", "test_folder_3/", true ) ).start();
//        new Thread( new ZipFile("input_file_1.txt", "himea_1.zip", "src") ).start();
    }
}